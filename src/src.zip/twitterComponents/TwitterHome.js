import React from 'react';
import TwitterLeftSide from './TwitterLeftSide';
import TwitterMiddle from './TwitterMiddle';
import TwitterRightSide from './TwitterRightSide';

function TwitterHome(props) {
    return (
        <div style={{display:"flex",justifyContent:"center",width:"80%",margin:"auto",marginTop:"5px"}}>
            <TwitterLeftSide/>
            <TwitterMiddle/>
            <TwitterRightSide/>
            
        </div>
    );
}

export default TwitterHome;